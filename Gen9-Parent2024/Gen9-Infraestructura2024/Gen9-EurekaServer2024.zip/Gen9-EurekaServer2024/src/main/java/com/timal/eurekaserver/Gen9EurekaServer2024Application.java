package com.timal.eurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gen9EurekaServer2024Application {

	public static void main(String[] args) {
		SpringApplication.run(Gen9EurekaServer2024Application.class, args);
	}

}
