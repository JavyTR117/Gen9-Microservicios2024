package com.timal.eurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gen9EurekaServer2024ApplicationTests {

	@Test
	void contextLoads() {
	}

}
